package org.ofbiz.backend.subscription;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.commons.lang.time.DateUtils;
import org.ofbiz.base.conversion.ConversionException;
import org.ofbiz.base.conversion.Converter;
import org.ofbiz.base.conversion.Converters;
import org.ofbiz.base.lang.JSON;
import org.ofbiz.base.util.UtilGenerics;
import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.entity.condition.EntityCondition;
import org.ofbiz.entity.condition.EntityOperator;
import org.ofbiz.entity.model.DynamicViewEntity;
import org.ofbiz.entity.model.ModelKeyMap;
import org.ofbiz.entity.util.EntityFindOptions;
import org.ofbiz.entity.util.EntityListIterator;
import org.ofbiz.entity.util.EntityUtil;
import org.ofbiz.webapp.event.EventHandlerException;

import com.ibm.icu.text.DateFormatSymbols;


public class DashboardContent
{
	public static final String module = DashboardContent.class.getName();
//	public static final EntityFindOptions findOptions = new EntityFindOptions(true, EntityFindOptions.TYPE_SCROLL_INSENSITIVE, EntityFindOptions.CONCUR_READ_ONLY, true);
	
	public static String getDashboardContentResult(HttpServletRequest request, HttpServletResponse response)
	{
		String dashboardContentType = request.getParameter("dashboardContentType");
		
		if(UtilValidate.isNotEmpty(dashboardContentType)) {
			if(dashboardContentType.equals("SubscriptionDistribution")) {
				return getSubscriptionDistribution(request, response);
			} else if(dashboardContentType.equals("TerritoryDistribution")) {
				return getTerritoryDistribution(request, response);
			} else if(dashboardContentType.equals("UserSubscriptionDistribution")) {
				return getUsersTerritoryWise(request, response);
			} else if(dashboardContentType.equals("EmployeeWisePaymentCollection")) {
				return getEmployeeWisePaymentCollection(request, response);
			} else if(dashboardContentType.equals("EmployeeMarketActiveStatus")) {
				return getEmployeeMarketActiveStatus(request, response);
			} else if(dashboardContentType.equals("MonthlyPayableStatus")) {
				return getMonthlyPayableStatus(request, response);
			} else if(dashboardContentType.equals("TerritoryWiseMonthlyPayStatus")) {
				return getTerritoryWiseMonthlyPayStatus(request, response);
			} else {
				return "error";
			}
		} else {
			return "error";
		}
	}
	
	public static String getSubscriptionDistribution(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		List<Map<String, Object>> subscriptionProductCountList = new ArrayList<Map<String,Object>>();
		Map<String, Object> subscriptionEachProductCount = new HashMap<String, Object>();
		GenericValue nextValue = null;
		long nubOfSubscription;
		
		Date presentTime = new Date();
        Timestamp presentDateTimestamp = new Timestamp(presentTime.getTime());
		
		try
		{
			EntityFindOptions findOptions = new EntityFindOptions();
			findOptions.setDistinct(true);
			
			EntityListIterator subscriptionResourceList = delegator.find("ProductSubscriptionResource", EntityCondition.makeCondition("fromDate", EntityOperator.LESS_THAN, presentDateTimestamp), null, UtilMisc.toSet("productId","subscriptionResourceId"), UtilMisc.toList("subscriptionResourceId"), findOptions);
			
			while((nextValue = (GenericValue) subscriptionResourceList.next()) != null) {
				nubOfSubscription = delegator.findCountByCondition("Subscription", EntityCondition.makeCondition("productId", EntityOperator.EQUALS, nextValue.getString("productId")), null, null);
				
				if(UtilValidate.isNotEmpty(nubOfSubscription) && nubOfSubscription > 0) {
					subscriptionEachProductCount = new HashMap<String, Object>();
					subscriptionEachProductCount.put("name", nextValue.getString("productId"));
					subscriptionEachProductCount.put("y", nubOfSubscription);
					subscriptionProductCountList.add(subscriptionEachProductCount);
				}
			}
			subscriptionResourceList.close();
			
			// Ajax response
			try 
			{
				Map<String, Object> subscriptionDistributionResult = new HashMap<String, Object>();
				
				if(UtilValidate.isNotEmpty(subscriptionProductCountList) && subscriptionProductCountList.size() > 0) {
					subscriptionDistributionResult.put("responseStatus", "Success");
					subscriptionDistributionResult.put("chartTitle", "");
					subscriptionDistributionResult.put("subscriptionDistributionList", subscriptionProductCountList);
				} else {
					subscriptionDistributionResult.put("responseStatus", "Error");
				}
				getMapToJsonObject(subscriptionDistributionResult, response);
			}
			catch (EventHandlerException e)
			{
				e.printStackTrace();
				return "error";
			}
			
			return "success";
		}
		catch(GenericEntityException gee)
		{
			gee.printStackTrace();
			return "error";
		}
	}
	
	public static String getTerritoryDistribution(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		String productId = request.getParameter("productId");
		
		List<Map<String, Object>> territoryDistributionList = new ArrayList<Map<String, Object>>();
		Map<String, Object> territoryDistributionResultMap = null;
		GenericValue geoGv;
		String geoIdEach;
		
		DynamicViewEntity dynamicEntity = new DynamicViewEntity();
		dynamicEntity.addMemberEntity("SUB", "Subscription");
		dynamicEntity.addMemberEntity("PCMP", "PartyContactMechPurpose");
		dynamicEntity.addMemberEntity("PAB", "PostalAddressBoundary");
		dynamicEntity.addMemberEntity("GEO", "Geo");
		dynamicEntity.addViewLink("SUB", "PCMP", false, ModelKeyMap.makeKeyMapList("partyId"));
		dynamicEntity.addViewLink("PCMP", "PAB", false, ModelKeyMap.makeKeyMapList("contactMechId"));
		dynamicEntity.addViewLink("PAB", "GEO", false, ModelKeyMap.makeKeyMapList("geoId"));
		dynamicEntity.addAlias("SUB", "productId");
		dynamicEntity.addAlias("SUB", "partyId");
		dynamicEntity.addAlias("PCMP", "contactMechPurposeTypeId");
		dynamicEntity.addAlias("PAB", "geoId");
		dynamicEntity.addAlias("GEO", "geoId");
		dynamicEntity.addAlias("GEO", "geoTypeId");
		
		EntityListIterator iterationOfDynamicEntity = null;
		
		try{
			if(UtilValidate.isNotEmpty(productId)){
				List<EntityCondition> conditionList = new ArrayList<EntityCondition>();
				conditionList.add(EntityCondition.makeCondition("productId", EntityOperator.EQUALS, productId));
				conditionList.add(EntityCondition.makeCondition("contactMechPurposeTypeId", EntityOperator.EQUALS, "BILLING_LOCATION"));
				conditionList.add(EntityCondition.makeCondition("geoTypeId", EntityOperator.EQUALS, "AREA"));
				
				iterationOfDynamicEntity = delegator.findListIteratorByCondition(dynamicEntity, EntityCondition.makeCondition(conditionList, EntityOperator.AND), null, UtilMisc.toSet("geoId"), UtilMisc.toList("geoId"), null);
				List<String> listOfUniqueGeoIds = EntityUtil.getFieldListFromEntityListIterator(iterationOfDynamicEntity, "geoId", true);
				
				iterationOfDynamicEntity.beforeFirst();
				List<String> listOfAllGeoIds = EntityUtil.getFieldListFromEntityListIterator(iterationOfDynamicEntity, "geoId", false);
				
				
				ListIterator<String> listOfUniqueGeoIdsIterator = listOfUniqueGeoIds.listIterator();
				
				while(listOfUniqueGeoIdsIterator.hasNext()) {
					geoIdEach = listOfUniqueGeoIdsIterator.next();
					if(UtilValidate.isNotEmpty(geoIdEach)){
						geoGv = delegator.findOne("Geo", UtilMisc.toMap("geoId", geoIdEach), false);
						
						territoryDistributionResultMap = new HashMap<String, Object>();
						territoryDistributionResultMap.put("geoId", geoIdEach);
						territoryDistributionResultMap.put("name", (UtilValidate.isNotEmpty(geoGv)) ? geoGv.get("geoName") : geoIdEach);
						territoryDistributionResultMap.put("y", Collections.frequency(listOfAllGeoIds, geoIdEach));
						territoryDistributionList.add(territoryDistributionResultMap);
					}
				}
				
				// Ajax response
				try 
				{
					Map<String, Object> territoryDistributionResult = new HashMap<String, Object>();
					
					if(UtilValidate.isNotEmpty(territoryDistributionList) && territoryDistributionList.size() > 0) {
						territoryDistributionResult.put("responseStatus", "Success");
						territoryDistributionResult.put("chartTitle", "Territory Distribution For : "+productId);
						territoryDistributionResult.put("productId", productId);
						territoryDistributionResult.put("subscriptionDistributionList", territoryDistributionList);
					} else {
						territoryDistributionResult.put("responseStatus", "Error");
					}
					getMapToJsonObject(territoryDistributionResult, response);
				}
				catch (EventHandlerException e)
				{
					e.printStackTrace();
					return "error";
				}
			}
			
			
			return "success";
		}
		catch(GenericEntityException e){
			e.printStackTrace();
			return "error";
			
		}
		finally{
			try{
				if(iterationOfDynamicEntity != null){
					iterationOfDynamicEntity.close();
				}
			}catch(GenericEntityException ge){
				ge.printStackTrace();
				return "error";
			}
		}
	}
	
	public static String getUsersTerritoryWise(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		String productId = request.getParameter("productId");
		String geoId = request.getParameter("geoId");
		
		DynamicViewEntity dynamicEntity = new DynamicViewEntity();
		  dynamicEntity.addMemberEntity("SUB", "Subscription");
		  dynamicEntity.addMemberEntity("PCMP", "PartyContactMechPurpose");
		  dynamicEntity.addMemberEntity("PAB", "PostalAddressBoundary");
		  dynamicEntity.addMemberEntity("USL", "UserLogin");
		  dynamicEntity.addViewLink("SUB", "USL", false, ModelKeyMap.makeKeyMapList("partyId"));
		  dynamicEntity.addViewLink("SUB", "PCMP", false, ModelKeyMap.makeKeyMapList("partyId"));
		  dynamicEntity.addViewLink("PCMP", "PAB", false, ModelKeyMap.makeKeyMapList("contactMechId"));
		  dynamicEntity.addAlias("USL", "firstName");
		  dynamicEntity.addAlias("USL", "subscriptionDate");
		  dynamicEntity.addAlias("SUB", "subscriptionId");
		  dynamicEntity.addAlias("SUB", "subscriptionCode");
		  dynamicEntity.addAlias("SUB", "productId");
		  dynamicEntity.addAlias("SUB", "partyId");
		  dynamicEntity.addAlias("PCMP", "contactMechPurposeTypeId");
		  dynamicEntity.addAlias("PAB", "geoId");
		  
		  Set<String> fieldsToSelect = new HashSet<String>();
		  fieldsToSelect.add("firstName");
		  fieldsToSelect.add("subscriptionDate");
		  fieldsToSelect.add("subscriptionId");
		  fieldsToSelect.add("subscriptionCode");
		
		EntityListIterator iterationOfDynamicEntity = null;
		GenericValue nextValue = null;
		List<Map<String, Object>> listofUsers = new  ArrayList<Map<String, Object>>();
		Map<String, Object> eachUserDetail = null;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		Timestamp subscriptionDateTs;
		
		try{
			List<EntityCondition> conditionList = new ArrayList<EntityCondition>();
			conditionList.add(EntityCondition.makeCondition("productId", EntityOperator.EQUALS, productId));
			conditionList.add(EntityCondition.makeCondition("geoId", EntityOperator.EQUALS, geoId));
			conditionList.add(EntityCondition.makeCondition("contactMechPurposeTypeId", EntityOperator.EQUALS, "BILLING_LOCATION"));
			
			iterationOfDynamicEntity = delegator.findListIteratorByCondition(dynamicEntity, EntityCondition.makeCondition(conditionList, EntityOperator.AND), null, fieldsToSelect, UtilMisc.toList("geoId"), null);
			
			//List<GenericValue> listofUsers = iterationOfDynamicEntity.getCompleteList();
			while((nextValue = (GenericValue) iterationOfDynamicEntity.next()) != null) {
				subscriptionDateTs = nextValue.getTimestamp("subscriptionDate");
				
				eachUserDetail = new HashMap<String, Object>();
				eachUserDetail.put("firstName", nextValue.get("firstName"));
				eachUserDetail.put("subscriptionDate", (UtilValidate.isNotEmpty(subscriptionDateTs)) ? dateFormatter.format(subscriptionDateTs) : null);
				eachUserDetail.put("subscriptionId", nextValue.get("subscriptionId"));
				eachUserDetail.put("subscriptionCode", nextValue.get("subscriptionCode"));
				
				listofUsers.add(eachUserDetail);
			}
			
			// Ajax response
			try 
			{
				Map<String, Object> usersTerritoryDistributionResult = new HashMap<String, Object>();
				
				if(UtilValidate.isNotEmpty(listofUsers) && listofUsers.size() > 0) {
					usersTerritoryDistributionResult.put("responseStatus", "Success");
					usersTerritoryDistributionResult.put("listofUsers", listofUsers);
				} else {
					usersTerritoryDistributionResult.put("responseStatus", "Error");
				}
				getMapToJsonObject(usersTerritoryDistributionResult, response);
			}
			catch (EventHandlerException e)
			{
				e.printStackTrace();
				return "error";
			}
			
			return "success";
		}catch(GenericEntityException gee){
			gee.printStackTrace();
			return "error";
		}finally{
			if(iterationOfDynamicEntity != null){
				try{
					iterationOfDynamicEntity.close();
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public static void getListToJsonObject(List<Map<String,Object>> list, HttpServletResponse response) throws EventHandlerException {
		JSON json = null;
        List<JSON> jsonList = new ArrayList<JSON>();
        if (list != null) {
            try {
	        	for(Map<String,Object> val : list) {
	            	Converter<Map<String,Object>, JSON> converter = UtilGenerics.cast(Converters.getConverter(Map.class, JSON.class));
	            	json = converter.convert(val);
	                jsonList.add(json);
	            }
            } catch(ConversionException | ClassNotFoundException e) {
            	throw new EventHandlerException("Problems with Conversion Map to Json", e);
            }
        }
        
        String jsonStr = jsonList.toString();
        if (jsonStr == null) {
        	throw new EventHandlerException("JSON Object was empty; fatal error!");
        }
        // set the X-JSON content type
        response.setContentType("application/json");
        // jsonStr.length is not reliable for unicode characters
        try {
        	response.setContentLength(jsonStr.getBytes("UTF8").length);
        } catch (UnsupportedEncodingException e) {
        	throw new EventHandlerException("Problems with Json encoding", e);
        }
        // return the JSON String
        Writer out;
        try {
        	out = response.getWriter();
        	out.write(jsonStr);
        	out.flush();
        } catch (IOException e) {
        	throw new EventHandlerException("Unable to get response writer", e);
        } 
    }
	
	public static void getMapToJsonObject(Map<String, Object> mapData, HttpServletResponse response) throws EventHandlerException {
		JSON json = null;
        if (UtilValidate.isNotEmpty(mapData)) {
            try {
            	Converter<Map<String, Object>, JSON> converter = UtilGenerics.cast(Converters.getConverter(Map.class, JSON.class));
            	json = converter.convert(mapData);
            } catch(ConversionException | ClassNotFoundException e) {
            	throw new EventHandlerException("Problems with Conversion Map to Json", e);
            }
        }
        
        String jsonStr = json.toString();
        if (jsonStr == null) {
        	throw new EventHandlerException("JSON Object was empty; fatal error!");
        }
        // set the X-JSON content type
        response.setContentType("application/json");
        // jsonStr.length is not reliable for unicode characters
        try {
        	response.setContentLength(jsonStr.getBytes("UTF8").length);
        } catch (UnsupportedEncodingException e) {
        	throw new EventHandlerException("Problems with Json encoding", e);
        }
        // return the JSON String
        Writer out;
        try {
        	out = response.getWriter();
        	out.write(jsonStr);
        	out.flush();
        } catch (IOException e) {
        	throw new EventHandlerException("Unable to get response writer", e);
        } 
    }
	
	public static String getEmployeeWisePaymentCollection(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		String fromDateRange = request.getParameter("fromDateRange");
		String thruDateRange = request.getParameter("thruDateRange");
		
		HttpSession session = request.getSession(true);
		GenericValue presentUserLogin = (GenericValue) session.getAttribute("userLogin");
		GenericValue nextValue = null;
		List<GenericValue> listOfUsers = new ArrayList<GenericValue>();
		List<GenericValue> listOfUserPayments = new ArrayList<GenericValue>();
		List<EntityCondition> conditionList = new ArrayList<EntityCondition>();
		List<Timestamp> dateRange = new ArrayList<Timestamp>();
		List<BigDecimal> amountInList = new ArrayList<BigDecimal>();
		Map<String, Object> listOfUserEachEmployeeCount = null;
		List<Map<String, Object>> notRecievedPaymentCollection = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> confirmedPaymentCollection = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> receivedPaymentCollection = new ArrayList<Map<String,Object>>();
		EntityListIterator userLoginsEli = null;
		BigDecimal amountInBigDecimal;
		Map<String, Object> employeeWisePaymentCollectionMap = new HashMap<String, Object>();
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		Timestamp fromDateSql = null, toDateSql = null;
		
		try
		{
			if(UtilValidate.isNotEmpty(fromDateRange) && UtilValidate.isNotEmpty(thruDateRange)) {
				System.out.println("Inside if date..");
				Date fromUtilDate = null, thruUtilDate = null;
				try {
					fromUtilDate = dateFormatter.parse(fromDateRange);
					thruUtilDate = dateFormatter.parse(thruDateRange);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				fromDateSql = new Timestamp(fromUtilDate.getTime());
				toDateSql = new Timestamp(DateUtils.addMilliseconds(DateUtils.ceiling(new Date(thruUtilDate.getTime()), Calendar.DATE), -1).getTime());
			} else {
				System.out.println("Inside else date..");
				Calendar fromDateCal = Calendar.getInstance();
				fromDateCal.setTime(new Date());
				fromDateCal.set(fromDateCal.get(Calendar.YEAR), fromDateCal.get(Calendar.MONTH), 1, 0, 0, 0);
				fromDateCal.set(Calendar.MILLISECOND, fromDateCal.getActualMinimum(Calendar.MILLISECOND));
				fromDateSql = new Timestamp(fromDateCal.getTimeInMillis());
				
				Calendar toDateCal = Calendar.getInstance();
				toDateCal.setTime(new Date());
				toDateCal.set(toDateCal.get(Calendar.YEAR), toDateCal.get(Calendar.MONTH), toDateCal.getActualMaximum(Calendar.DATE), 23, 59, 59);
				toDateCal.set(Calendar.MILLISECOND, toDateCal.getActualMaximum(Calendar.MILLISECOND));
				toDateSql = new Timestamp(toDateCal.getTimeInMillis());
			}
			
			dateRange.add(fromDateSql);
			dateRange.add(toDateSql);
			System.out.println("dateRange == "+dateRange);
			
			EntityCondition entityCondition = EntityCondition.makeCondition(
					EntityCondition.makeCondition("partyStatusId","PARTY_ENABLED"),
					EntityOperator.AND,
					EntityCondition.makeCondition("roleTypeIdTo", "EMPLOYEE")
					);
			
			List<GenericValue> partyIds = delegator.findList("PartyRelationshipAndDetail", entityCondition, UtilMisc.toSet("partyId"), null, null, false);
			
			entityCondition = EntityCondition.makeCondition(
					EntityCondition.makeCondition("companyId", presentUserLogin.get("companyId")),
					EntityOperator.AND,
					EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(partyIds, "partyId", false))
					);
			
			userLoginsEli = delegator.find("UserLogin", entityCondition, null, UtilMisc.toSet("userLoginId","companyId"), null, null);
			
			while((nextValue = (GenericValue) userLoginsEli.next()) != null)
			{
				listOfUsers.clear();
//				listOfUsers = SubscriptionServicesUtil.getUsers(UtilMisc.toMap("username",nextValue.getString("userLoginId"),"companyId",nextValue.getString("companyId")));
				
				listOfUsers = getUsers(delegator, UtilMisc.toMap("username",nextValue.getString("userLoginId"),"companyId",nextValue.getString("companyId")));
				
				
				//Payment Not Recieved
				listOfUserPayments.clear();
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("statusId", "PMNT_NOT_PAID"));
				conditionList.add(EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false)));
				conditionList.add(EntityCondition.makeCondition("effectiveDate", EntityOperator.BETWEEN, dateRange));
				
				/*entityCondition = EntityCondition.makeCondition(
						EntityCondition.makeCondition("statusId", "PMNT_NOT_PAID"),
						EntityOperator.AND,
						EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false))
						);*/
				
				listOfUserPayments = delegator.findList("PaymentAndTypeAndCreditCard", EntityCondition.makeCondition(conditionList, EntityOperator.AND), UtilMisc.toSet("partyIdFrom","amount"), null, null, false);
				amountInList = (UtilValidate.isNotEmpty(listOfUserPayments) ? EntityUtil.getFieldListFromEntityList(listOfUserPayments, "amount", false) : null);
				amountInBigDecimal = (UtilValidate.isNotEmpty(listOfUserPayments) ? amountInList.stream().reduce(BigDecimal.ZERO, BigDecimal::add) : BigDecimal.ZERO);
				listOfUserEachEmployeeCount.put("label", nextValue.getString("userLoginId"));
				listOfUserEachEmployeeCount.put("y", amountInBigDecimal);
				notRecievedPaymentCollection.add(listOfUserEachEmployeeCount);
				
				
				
				//Payment Confirmed
				listOfUserPayments.clear();
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("statusId", "PMNT_CONFIRMED"));
				conditionList.add(EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false)));
				conditionList.add(EntityCondition.makeCondition("effectiveDate", EntityOperator.BETWEEN, dateRange));
				
				/*entityCondition = EntityCondition.makeCondition(
						EntityCondition.makeCondition("statusId", "PMNT_CONFIRMED"),
						EntityOperator.AND,
						EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false))
						);*/
				
				listOfUserPayments = delegator.findList("PaymentAndTypeAndCreditCard", EntityCondition.makeCondition(conditionList, EntityOperator.AND), UtilMisc.toSet("partyIdFrom","amount"), null, null, false);
				amountInList = (UtilValidate.isNotEmpty(listOfUserPayments) ? EntityUtil.getFieldListFromEntityList(listOfUserPayments, "amount", false) : null);
				amountInBigDecimal = (UtilValidate.isNotEmpty(listOfUserPayments) ? amountInList.stream().reduce(BigDecimal.ZERO, BigDecimal::add) : BigDecimal.ZERO);
				listOfUserEachEmployeeCount.put("label", nextValue.getString("userLoginId"));
				listOfUserEachEmployeeCount.put("y", amountInBigDecimal);
				confirmedPaymentCollection.add(listOfUserEachEmployeeCount);
				
				
				
				//Payment Received
				listOfUserPayments.clear();
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("statusId", "PMNT_RECEIVED"));
				conditionList.add(EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false)));
				conditionList.add(EntityCondition.makeCondition("effectiveDate", EntityOperator.BETWEEN, dateRange));
				
				/*entityCondition = EntityCondition.makeCondition(
						EntityCondition.makeCondition("statusId", "PMNT_RECEIVED"),
						EntityOperator.AND,
						EntityCondition.makeCondition("partyIdFrom", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false))
						);*/
				
				listOfUserPayments = delegator.findList("PaymentAndTypeAndCreditCard", EntityCondition.makeCondition(conditionList, EntityOperator.AND), UtilMisc.toSet("partyIdFrom","amount"), null, null, false);
				amountInList = (UtilValidate.isNotEmpty(listOfUserPayments) ? EntityUtil.getFieldListFromEntityList(listOfUserPayments, "amount", false) : null);
				amountInBigDecimal = (UtilValidate.isNotEmpty(listOfUserPayments) ? amountInList.stream().reduce(BigDecimal.ZERO, BigDecimal::add) : BigDecimal.ZERO);
				listOfUserEachEmployeeCount.put("label", nextValue.getString("userLoginId"));
				listOfUserEachEmployeeCount.put("y", amountInBigDecimal);
				receivedPaymentCollection.add(listOfUserEachEmployeeCount);
				
			}
			System.out.println("conditionList = "+conditionList);
			
			employeeWisePaymentCollectionMap.put("Confirmed", confirmedPaymentCollection);
			employeeWisePaymentCollectionMap.put("Received", receivedPaymentCollection);
			employeeWisePaymentCollectionMap.put("NotPaid", notRecievedPaymentCollection);
			
			// Ajax response
			try 
			{
				Map<String, Object> employeePaymentCollectResult = new HashMap<String, Object>();
				
				employeePaymentCollectResult.put("responseStatus", "Success");
				employeePaymentCollectResult.put("chartTitle", "From: "+dateFormatter.format(fromDateSql)+" To: "+dateFormatter.format(toDateSql));
				employeePaymentCollectResult.put("employeeWisePaymentCollectionMap", employeeWisePaymentCollectionMap);
				
				getMapToJsonObject(employeePaymentCollectResult, response);
			}
			catch (EventHandlerException e)
			{
				e.printStackTrace();
				return "error";
			}
			
			return "success";
		}
		catch(GenericEntityException gee)
		{
			gee.printStackTrace();
			return "error";
		}
		finally
		{
			try {
				if(UtilValidate.isNotEmpty(userLoginsEli)) {
					userLoginsEli.close();
				}
			} catch (GenericEntityException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static List<GenericValue> getUsers(Delegator delegator, Map<String, Object> paramMap){
    	List<GenericValue> classes = null;
    	try{
    		GenericValue userLogin = EntityUtil.getFirst(delegator.findByAnd("UserLogin", UtilMisc.toMap("userLoginId", paramMap.get("username"), "companyId",paramMap.get("companyId"),"enabled","Y"),null, false));
    		if(UtilValidate.isNotEmpty(userLogin) && (UtilValidate.isEmpty(userLogin.getBoolean("isChangeInList")) || userLogin.getBoolean("isChangeInList")) ){
    			EntityCondition entityCondition = EntityCondition.makeCondition(
    												EntityCondition.makeCondition("partyId", userLogin.getString("partyId")), 
    													EntityOperator.AND,
    												EntityCondition.makeCondition("thruDate", null));
    			classes = delegator.findList("PartyClassification", entityCondition, UtilMisc.toSet("partyClassificationGroupId"), UtilMisc.toList("fromDate"), null, false);
    			
    			if(UtilValidate.isNotEmpty(classes)){
    				entityCondition = EntityCondition.makeCondition(
							EntityCondition.makeCondition("partyClassificationTypeId", "EMPLOYEE_TERRITORY"), 
							EntityOperator.AND,
						EntityCondition.makeCondition("partyClassificationGroupId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(classes, "partyClassificationGroupId", true)));
    				classes.clear();
    				classes = delegator.findList("PartyClassificationGroup", entityCondition, UtilMisc.toSet("description"), null, null, false);
    				
    				if(UtilValidate.isNotEmpty(classes)){
    					//PARTY_TERRITORY
    					entityCondition = EntityCondition.makeCondition(
    							EntityCondition.makeCondition("partyIdentificationTypeId", "PARTY_TERRITORY"), 
    							EntityOperator.AND,
    						EntityCondition.makeCondition("idValue", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(classes, "description", true)));
    					classes = delegator.findList("PartyIdentification", entityCondition, UtilMisc.toSet("partyId"), null, null, false);
    					
    					if(UtilValidate.isNotEmpty(classes)){
    						entityCondition = EntityCondition.makeCondition(
        							EntityCondition.makeCondition(UtilMisc.toMap("roleTypeIdFrom", "INTERNAL_ORGANIZATIO", "roleTypeIdTo","CUSTOMER","partyRelationshipTypeId", "CUSTOMER_REL", "partyIdFrom", paramMap.get("companyId"))), 
        							EntityOperator.AND,
        						EntityCondition.makeCondition("partyIdTo", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(classes, "partyId", true)));
        					classes = delegator.findList("PartyRelationship", entityCondition, UtilMisc.toSet("partyIdTo"), null, null, false);
        					
        					if(UtilValidate.isNotEmpty(classes)){
        						entityCondition = EntityCondition.makeCondition(
            							EntityCondition.makeCondition("enabled","Y"), 
            							EntityOperator.AND,
            						EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(classes, "partyIdTo", true)));
            					classes = delegator.findList("UserLogin", entityCondition, UtilMisc.toSet("partyId", "userLoginId"), null, null, false);
            					
            					// Need to store this result in the PartyAttribute table, so that we can't retrieve the data again and again
            					if(UtilValidate.isNotEmpty(classes)){
            						List<GenericValue> toBeStored = new LinkedList<GenericValue>();
            						for(GenericValue gv : classes){
            							toBeStored.add(delegator.makeValue("PartyAttribute", UtilMisc.toMap("partyId", userLogin.get("partyId"), "attrName", gv.getString("partyId"), "attrValue", gv.getString("userLoginId"))));
            						}
            						delegator.storeAll(toBeStored);
            					}
            					
            					if(UtilValidate.isEmpty(userLogin.getBoolean("isChangeInList")) || userLogin.getBoolean("isChangeInList")){
            						userLogin.set("isChangeInList", "N");
            						userLogin.store();
            					}
            					
        					}
    					}
    					
    				}
    			}
    		}else{
    			classes = delegator.findList("PartyAttribute", EntityCondition.makeCondition("partyId", userLogin.getString("partyId")), UtilMisc.toSet("attrName", "attrValue"), null, null, false);
    		}
    		
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return classes;
    }
	
	public static String getEmployeeMarketActiveStatus(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		String dateSelected = request.getParameter("dateSelected");
		String employeeActiveType = request.getParameter("employeeActiveType");
		
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd-MM-yyyy");
		List<Map<String, Object>> employeeMarketActiveStatus = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> activeLoginResultList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> notActiveLoginResultList = new ArrayList<Map<String, Object>>();
		List<GenericValue> userLoginHistoryListGvs = null;
		List<EntityCondition> userLoginHistoryCondn = new ArrayList<EntityCondition>();
		List<Timestamp> dateRange = new ArrayList<Timestamp>();
		Map<String, Object> userLoginHistoryMap = null;
		GenericValue nextValue = null, partyClassGrpGv = null, geoGv = null;
		EntityListIterator partyClassEli = null;
		Timestamp fromDate = null, toDate = null, dateSelectedTs = null;
		int activeLogins = 0, notActiveLogins = 0;
		
		if(UtilValidate.isNotEmpty(dateSelected)) {
			Date date = new Date();
			try {
				date = dateFormatter.parse(dateSelected);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			dateSelectedTs = new Timestamp(date.getTime()+36000);
		} else {
			dateSelectedTs = new Timestamp(new Date().getTime());
		}
		fromDate = new Timestamp(DateUtils.truncate(new Date(dateSelectedTs.getTime()), Calendar.DATE).getTime());
		toDate = new Timestamp(DateUtils.addMilliseconds(DateUtils.ceiling(new Date(dateSelectedTs.getTime()), Calendar.DATE), -1).getTime());
		
		dateRange.add(fromDate);
		dateRange.add(toDate);
		System.out.println("dateRange = "+dateRange);
		
		try
		{
			EntityCondition entityCondition = EntityCondition.makeCondition(
					EntityCondition.makeCondition("partyStatusId","PARTY_ENABLED"),
					EntityOperator.AND,
					EntityCondition.makeCondition("roleTypeIdTo", "EMPLOYEE")
					);
			
			List<GenericValue> partyIds = delegator.findList("PartyRelationshipAndDetail", entityCondition, UtilMisc.toSet("partyId"), null, null, false);
			
			if(UtilValidate.isNotEmpty(partyIds) && partyIds.size() > 0) {
				entityCondition = EntityCondition.makeCondition(
						EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(partyIds, "partyId", false)), 
						EntityOperator.AND,
						EntityCondition.makeCondition("thruDate", null));
				
				partyClassEli = delegator.find("PartyClassification", entityCondition, null, UtilMisc.toSet("partyId","partyClassificationGroupId"), UtilMisc.toList("partyId"), null);
				
				EntityFindOptions findOptions = new EntityFindOptions();
				findOptions.setDistinct(true);
				
				while((nextValue = (GenericValue) partyClassEli.next()) != null) {
					partyClassGrpGv = delegator.findOne("PartyClassificationGroup", UtilMisc.toMap("partyClassificationGroupId", nextValue.get("partyClassificationGroupId")), false);
				
					if(UtilValidate.isNotEmpty(partyClassGrpGv) && partyClassGrpGv.get("partyClassificationTypeId").equals("EMPLOYEE_TERRITORY")) {
						geoGv = delegator.findOne("Geo", UtilMisc.toMap("geoId", partyClassGrpGv.get("description")), false);
					}
					
					userLoginHistoryCondn.clear();
					userLoginHistoryCondn.add(EntityCondition.makeCondition("partyId", nextValue.get("partyId")));
					userLoginHistoryCondn.add(EntityCondition.makeCondition("fromDate", EntityOperator.BETWEEN, dateRange));
					userLoginHistoryCondn.add(EntityCondition.makeCondition("successfulLogin", "Y"));
					System.out.println("userLoginHistoryCondn = "+userLoginHistoryCondn);
					
					entityCondition = EntityCondition.makeCondition(userLoginHistoryCondn, EntityOperator.AND);
					
					userLoginHistoryListGvs = delegator.findList("UserLoginHistory", entityCondition, UtilMisc.toSet("userLoginId", "fromDate"), UtilMisc.toList("fromDate"), findOptions, false);
				
					if(UtilValidate.isNotEmpty(userLoginHistoryListGvs) && userLoginHistoryListGvs.size() > 0){ activeLogins++; } else { notActiveLogins++; }
					
					if(UtilValidate.isNotEmpty(employeeActiveType) && employeeActiveType.equals("Active") && UtilValidate.isNotEmpty(userLoginHistoryListGvs) && userLoginHistoryListGvs.size() > 0)
					{
						//Get Active Logins
						userLoginHistoryMap = new HashMap<String, Object>();
						userLoginHistoryMap.put("userLoginId", userLoginHistoryListGvs.get(0).get("userLoginId"));
						userLoginHistoryMap.put("userLoginTime", userLoginHistoryListGvs.get(0).get("fromDate")+"");
						userLoginHistoryMap.put("userGeoTerritory", (UtilValidate.isNotEmpty(geoGv)) ? geoGv.get("geoName") : null);
						
						activeLoginResultList.add(userLoginHistoryMap);
					}
					else if(UtilValidate.isNotEmpty(employeeActiveType) && employeeActiveType.equals("InActive") && UtilValidate.isEmpty(userLoginHistoryListGvs))
					{
						// Get Not Active Logins
						userLoginHistoryCondn.clear();
						userLoginHistoryCondn.add(EntityCondition.makeCondition("partyId", nextValue.get("partyId")));
						userLoginHistoryCondn.add(EntityCondition.makeCondition("fromDate", EntityOperator.LESS_THAN, fromDate));
						userLoginHistoryCondn.add(EntityCondition.makeCondition("successfulLogin", "Y"));
						
						entityCondition = EntityCondition.makeCondition(userLoginHistoryCondn, EntityOperator.AND);
						
						userLoginHistoryListGvs = delegator.findList("UserLoginHistory", entityCondition, UtilMisc.toSet("userLoginId", "fromDate"), UtilMisc.toList("fromDate DESC"), findOptions, false);
						
						if(UtilValidate.isNotEmpty(userLoginHistoryListGvs) && userLoginHistoryListGvs.size() > 0)
						{
							userLoginHistoryMap = new HashMap<String, Object>();
							userLoginHistoryMap.put("userLoginId", userLoginHistoryListGvs.get(0).get("userLoginId"));
							userLoginHistoryMap.put("userLoginTime", userLoginHistoryListGvs.get(0).get("fromDate")+"");
							userLoginHistoryMap.put("userGeoTerritory", (UtilValidate.isNotEmpty(geoGv)) ? geoGv.get("geoName") : null);
							
							notActiveLoginResultList.add(userLoginHistoryMap);
						} else {
							// get user login id info from UserLogin table
							userLoginHistoryListGvs = delegator.findList("UserLogin", EntityCondition.makeCondition("partyId", nextValue.get("partyId")), UtilMisc.toSet("userLoginId"), UtilMisc.toList("userLoginId"), findOptions, false);
							
							if(UtilValidate.isNotEmpty(userLoginHistoryListGvs) && userLoginHistoryListGvs.size() > 0)
							{
								userLoginHistoryMap = new HashMap<String, Object>();
								userLoginHistoryMap.put("userLoginId", userLoginHistoryListGvs.get(0).get("userLoginId"));
								userLoginHistoryMap.put("userLoginTime", null);
								userLoginHistoryMap.put("userGeoTerritory", (UtilValidate.isNotEmpty(geoGv)) ? geoGv.get("geoName") : null);
								
								notActiveLoginResultList.add(userLoginHistoryMap);
							}
						}
					}
				}
				
				// Ajax response
				try 
				{
					Map<String, Object> employeeActiveStatusResult = new HashMap<String, Object>();
					
					if(UtilValidate.isNotEmpty(employeeActiveType) && employeeActiveType.equals("Active")) {
						employeeActiveStatusResult.put("responseStatus", "Success");
						employeeActiveStatusResult.put("employeeResultList", activeLoginResultList);
					}
					else if(UtilValidate.isNotEmpty(employeeActiveType) && employeeActiveType.equals("InActive")) {
						employeeActiveStatusResult.put("responseStatus", "Success");
						employeeActiveStatusResult.put("employeeResultList", notActiveLoginResultList);
					}
					else if(UtilValidate.isNotEmpty(activeLogins) && UtilValidate.isNotEmpty(notActiveLogins)) {
						// Entry For Active Logins
						userLoginHistoryMap = new HashMap<String, Object>();
						userLoginHistoryMap.put("name", "Active");
						userLoginHistoryMap.put("y", activeLogins);
						employeeMarketActiveStatus.add(userLoginHistoryMap);
						
						// Entry For Not Active Logins
						userLoginHistoryMap = new HashMap<String, Object>();
						userLoginHistoryMap.put("name", "InActive");
						userLoginHistoryMap.put("y", notActiveLogins);
						employeeMarketActiveStatus.add(userLoginHistoryMap);
						
						System.out.println("employeeMarketActiveStatus = "+employeeMarketActiveStatus);
						
						employeeActiveStatusResult.put("responseStatus", "Success");
						employeeActiveStatusResult.put("chartTitle", dateFormatter.format(dateSelectedTs));
						employeeActiveStatusResult.put("employeeMarketActiveStatus", employeeMarketActiveStatus);
						employeeActiveStatusResult.put("dateSelected", dateFormatter.format(dateSelectedTs));
					} else {
						employeeActiveStatusResult.put("responseStatus", "Error");
					}
					
					getMapToJsonObject(employeeActiveStatusResult, response);
				}
				catch (EventHandlerException e)
				{
					e.printStackTrace();
					return "error";
				}
				
			}
			
			return "success";
		}
		catch(GenericEntityException gee)
		{
			gee.printStackTrace();
			return "error";
		}
		finally
		{
			try {
				partyClassEli.close();
			} catch (GenericEntityException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static String getMonthlyPayableStatus(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		String yearSelected = request.getParameter("yearSelected");
		
		DynamicViewEntity dynamicEntity = new DynamicViewEntity();
		dynamicEntity.addMemberEntity("INV", "Invoice");
		dynamicEntity.addMemberEntity("INI", "InvoiceItem");
		dynamicEntity.addMemberEntity("ULG", "UserLogin");
		dynamicEntity.addViewLink("INV", "INI", false, ModelKeyMap.makeKeyMapList("invoiceId"));
		dynamicEntity.addViewLink("INV", "ULG", false, ModelKeyMap.makeKeyMapList("partyId"));
		dynamicEntity.addAlias("INV", "invoiceDate");
		dynamicEntity.addAlias("INV", "statusId");
		dynamicEntity.addAlias("INI", "amount");
		dynamicEntity.addAlias("ULG", "enabled");
		
		String[] monthsList = new DateFormatSymbols().getMonths();
		
		EntityListIterator invoiceLst = null;
		List<Map<String, Object>> invoiceList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> paymentList = new ArrayList<Map<String, Object>>();
		List<Map<String, Object>> outStandingList = new ArrayList<Map<String, Object>>();
		int year;
		
		try{
			if(UtilValidate.isNotEmpty(yearSelected)) {
				year = Integer.parseInt(yearSelected);
			} else {
				year = Calendar.getInstance().get(Calendar.YEAR);
			}
			
			
			Calendar fromDate = Calendar.getInstance();
			fromDate.set(year, 3, 1, 0, 0, 0);
			fromDate.set(Calendar.MILLISECOND, fromDate.getMinimum(Calendar.MILLISECOND));
			
			Timestamp fromTime = new Timestamp(fromDate.getTimeInMillis());
			
			year = year+1;
			
			Calendar toDate = Calendar.getInstance();
			toDate.set(Calendar.YEAR, year);
			toDate.set(Calendar.MONTH, 2);
			toDate.set(Calendar.DATE, toDate.getActualMaximum(Calendar.DATE));
			toDate.set(Calendar.HOUR, 23);
			toDate.set(Calendar.MINUTE, 59);
			toDate.set(Calendar.SECOND, 59);
			toDate.set(Calendar.MILLISECOND, toDate.getMaximum(Calendar.MILLISECOND));
			
			Timestamp toTime = new Timestamp(toDate.getTimeInMillis());
			
			List<Timestamp> orderBetween = new ArrayList<Timestamp>();
			orderBetween.add(fromTime);
			orderBetween.add(toTime);
			
			List<EntityCondition> entityCondition = new ArrayList<EntityCondition>();
			entityCondition.add(EntityCondition.makeCondition("invoiceDate", EntityOperator.BETWEEN, orderBetween));
			entityCondition.add(EntityCondition.makeCondition("enabled", EntityOperator.EQUALS, "Y"));
			
			invoiceLst = delegator.findListIteratorByCondition(dynamicEntity, EntityCondition.makeCondition(entityCondition, EntityOperator.AND), null, UtilMisc.toSet("amount", "statusId", "invoiceDate"), UtilMisc.toList("invoiceDate"), null);
			
			Map<String, Object> invoiceMap = new HashMap<String, Object>();
			Map<String, Object> paymentMap = new HashMap<String, Object>();
			Map<String, Object> outStandingMap = new HashMap<String, Object>();
			
			int j;
			for(int i=3; i<=14; i++){
				j = (i > 11) ? i-12 : i;
				invoiceMap.put(monthsList[j],BigDecimal.ZERO);
				paymentMap.put(monthsList[j],BigDecimal.ZERO);
				outStandingMap.put(monthsList[j],BigDecimal.ZERO);
			}
			
			GenericValue value = null;
			int redmonth;
			String monthName, statusId;
			BigDecimal amount, prevamount;
			Timestamp month;
			Calendar cal = Calendar.getInstance();
            while (((value = invoiceLst.next()) != null)) {
            	statusId = value.getString("statusId");
            	amount = value.getBigDecimal("amount");
            	month = value.getTimestamp("invoiceDate");
            	cal.setTimeInMillis(month.getTime());
            	redmonth = cal.get(Calendar.MONTH);
            	monthName = monthsList[redmonth];
            	
            	if(invoiceMap.containsKey(monthName)){
            		//For Invoice
            		prevamount = (BigDecimal) invoiceMap.get(monthName);
            		prevamount = prevamount.add(amount);
            		invoiceMap.put(monthName, prevamount);
            		
            		//For Payment
            		if(statusId.equals("INVOICE_PAID") && paymentMap.containsKey(monthName)) {
            			prevamount = (BigDecimal) paymentMap.get(monthName);
                		prevamount = prevamount.add(amount);
                		paymentMap.put(monthName, prevamount);
            		} else if(statusId.equals("INVOICE_PAID")) {
            			paymentMap.put(monthName, amount);
            		}
            	}
            }
            
			BigDecimal tempInv, tempPay, tempOut;
            
            for(int i=3; i<=14; i++){
				j = (i > 11) ? i-12 : i;
				
				tempInv = (BigDecimal) invoiceMap.get(monthsList[j]);
                tempPay = (BigDecimal)  paymentMap.get(monthsList[j]);
                tempOut = tempInv.subtract(tempPay);
				
				invoiceList.add(UtilMisc.toMap("label", monthsList[j], "y", invoiceMap.get(monthsList[j]), "monthNumber", j));
				paymentList.add(UtilMisc.toMap("label", monthsList[j], "y", paymentMap.get(monthsList[j]), "monthNumber", j));
				outStandingList.add(UtilMisc.toMap("label", monthsList[j], "y", tempOut, "monthNumber", j));
			}
            
         // Ajax response
            try 
            {
            	Map<String, Object> monthlyPayableStatusResult = new HashMap<String, Object>();
            	
            	monthlyPayableStatusResult.put("responseStatus", "Success");
            	monthlyPayableStatusResult.put("chartTitle", "For the year "+ --year + " - "+ ++year);
            	monthlyPayableStatusResult.put("yearSelected", --year);
            	monthlyPayableStatusResult.put("invoiceList", invoiceList);
            	monthlyPayableStatusResult.put("paymentList", paymentList);
            	monthlyPayableStatusResult.put("outStandingList", outStandingList);
            	
            	getMapToJsonObject(monthlyPayableStatusResult, response);
            }
            catch (EventHandlerException e)
            {
            	e.printStackTrace();
            	return "error";
            }
            
            return "success";
            
		}catch(GenericEntityException e){
			e.printStackTrace();
			return "error";
			
		}finally{
			if(invoiceLst != null){
				try{
					invoiceLst.close();
				}catch(GenericEntityException gee){
					gee.printStackTrace();
					return "error";
				}
			}
		}
	}
	
	public static String getTerritoryWiseMonthlyPayStatus(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		String monthSelected = request.getParameter("monthSelected");
		String yearSelected = request.getParameter("yearSelected");
		
		HttpSession session = request.getSession(true);
		GenericValue presentUserLogin = (GenericValue) session.getAttribute("userLogin");
		GenericValue nextValue = null;
		List<GenericValue> listOfUsers = new ArrayList<GenericValue>();
		List<EntityCondition> conditionList = new ArrayList<EntityCondition>();
		List<Timestamp> dateRange = new ArrayList<Timestamp>();
		List<BigDecimal> amountInList = new ArrayList<BigDecimal>();
		Map<String, Object> listOfUserEachEmployeeCount = null;
		List<Map<String, Object>> outStandingList = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> invoiceList = new ArrayList<Map<String,Object>>();
		List<Map<String, Object>> paymentList = new ArrayList<Map<String,Object>>();
		EntityListIterator userLoginsEli = null;
		EntityListIterator territoryList = null;
		BigDecimal amountInBigDecimal, outStandingAmount;
		String[] monthsList = new DateFormatSymbols().getMonths();
		String territoryName;
		
		List<GenericValue> listOfUserPay = new ArrayList<GenericValue>();
		
		DynamicViewEntity dynamicEntity = new DynamicViewEntity();
		dynamicEntity.addMemberEntity("PAC", "PartyClassification");
		dynamicEntity.addMemberEntity("PCG", "PartyClassificationGroup");
		dynamicEntity.addMemberEntity("GN", "Geo");
		dynamicEntity.addViewLink("PAC", "PCG", false, ModelKeyMap.makeKeyMapList("partyClassificationGroupId"));
		dynamicEntity.addViewLink("PCG", "GN", false, ModelKeyMap.makeKeyMapList("description", "geoId"));
		dynamicEntity.addAlias("PAC", "partyId");
		dynamicEntity.addAlias("PCG", "partyClassificationTypeId");
		dynamicEntity.addAlias("PCG", "description");
		dynamicEntity.addAlias("GN", "geoName");
		dynamicEntity.addAlias("GN", "geoTypeId");
		
		try
		{
			int yearInt = (UtilValidate.isNotEmpty(yearSelected) && NumberUtils.isNumber(yearSelected)) ? Integer.parseInt(yearSelected) : Calendar.getInstance().get(Calendar.YEAR);
			int monthInt = (UtilValidate.isNotEmpty(monthSelected) && NumberUtils.isNumber(monthSelected)) ? Integer.parseInt(monthSelected) : Calendar.getInstance().get(Calendar.MONTH);
			
			Calendar fromTime = Calendar.getInstance();
			fromTime.set(Calendar.YEAR, yearInt);
			fromTime.set(Calendar.MONTH, monthInt);
			fromTime.set(Calendar.DATE, 1);
			fromTime.set(Calendar.HOUR, 0);
			fromTime.set(Calendar.MINUTE, 0);
			fromTime.set(Calendar.SECOND, 0);
			fromTime.set(Calendar.MILLISECOND, fromTime.getMinimum(Calendar.MILLISECOND));
			
			Timestamp fromDate = new Timestamp(fromTime.getTimeInMillis());
			
			fromTime.set(Calendar.DATE, fromTime.getMaximum(Calendar.DATE));
			fromTime.set(Calendar.HOUR, 23);
			fromTime.set(Calendar.MINUTE, 59);
			fromTime.set(Calendar.SECOND, 59);
			fromTime.set(Calendar.MILLISECOND, fromTime.getMaximum(Calendar.MILLISECOND));
			
			Timestamp thruDate = new Timestamp(fromTime.getTimeInMillis());
			
			dateRange.add(fromDate);
			dateRange.add(thruDate);
			
			EntityCondition entityCondition = EntityCondition.makeCondition(
					EntityCondition.makeCondition("partyStatusId","PARTY_ENABLED"),
					EntityOperator.AND,
					EntityCondition.makeCondition("roleTypeIdTo", "EMPLOYEE")
					);
			
			List<GenericValue> partyIds = delegator.findList("PartyRelationshipAndDetail", entityCondition, UtilMisc.toSet("partyId"), null, null, false);
			
			entityCondition = EntityCondition.makeCondition(
					EntityCondition.makeCondition("companyId", presentUserLogin.get("companyId")),
					EntityOperator.AND,
					EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(partyIds, "partyId", false))
					);
			
			userLoginsEli = delegator.find("UserLogin", entityCondition, null, UtilMisc.toSet("userLoginId","companyId","partyId"), null, null);
			
			while((nextValue = (GenericValue) userLoginsEli.next()) != null)
			{
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("partyId", nextValue.get("partyId")));
				conditionList.add(EntityCondition.makeCondition("partyClassificationTypeId", "EMPLOYEE_TERRITORY"));
				conditionList.add(EntityCondition.makeCondition("geoTypeId", "TERRITORY"));
				
				territoryList = delegator.findListIteratorByCondition(dynamicEntity, EntityCondition.makeCondition(conditionList, EntityOperator.AND), null, UtilMisc.toSet("geoName"), null, null);
				
				if(UtilValidate.isNotEmpty(territoryList)) {
					territoryName = territoryList.next().getString("geoName");
				} else {
					territoryName = nextValue.getString("userLoginId");
				}
				
				listOfUsers.clear();
				
				listOfUsers = getUsers(delegator, UtilMisc.toMap("username",nextValue.getString("userLoginId"),"companyId",nextValue.getString("companyId")));
				
				//Total Invoice (Invoice)
				listOfUserPay.clear();
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false)));
				conditionList.add(EntityCondition.makeCondition("invoiceDate", EntityOperator.BETWEEN, dateRange));
				
				listOfUserPay = delegator.findList("InvoiceAndItem", EntityCondition.makeCondition(conditionList, EntityOperator.AND), UtilMisc.toSet("partyId","amount"), null, null, false);
				
				amountInList = (UtilValidate.isNotEmpty(listOfUserPay) ? EntityUtil.getFieldListFromEntityList(listOfUserPay, "amount", false) : null);
				amountInBigDecimal = (UtilValidate.isNotEmpty(listOfUserPay) ? amountInList.stream().reduce(BigDecimal.ZERO, BigDecimal::add) : BigDecimal.ZERO);
				outStandingAmount = amountInBigDecimal;
				listOfUserEachEmployeeCount.put("label", territoryName);
				listOfUserEachEmployeeCount.put("y", amountInBigDecimal);
				invoiceList.add(listOfUserEachEmployeeCount);
				
				//Invoice Paid (Payment)
				listOfUserPay.clear();
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				conditionList.clear();
				conditionList.add(EntityCondition.makeCondition("statusId", "INVOICE_PAID"));
				conditionList.add(EntityCondition.makeCondition("partyId", EntityOperator.IN, EntityUtil.getFieldListFromEntityList(listOfUsers, "attrName", false)));
				conditionList.add(EntityCondition.makeCondition("invoiceDate", EntityOperator.BETWEEN, dateRange));
				
				listOfUserPay = delegator.findList("InvoiceAndItem", EntityCondition.makeCondition(conditionList, EntityOperator.AND), UtilMisc.toSet("partyId","amount"), null, null, false);
				
				amountInList = (UtilValidate.isNotEmpty(listOfUserPay) ? EntityUtil.getFieldListFromEntityList(listOfUserPay, "amount", false) : null);
				amountInBigDecimal = (UtilValidate.isNotEmpty(listOfUserPay) ? amountInList.stream().reduce(BigDecimal.ZERO, BigDecimal::add) : BigDecimal.ZERO);
				listOfUserEachEmployeeCount.put("label", territoryName);
				listOfUserEachEmployeeCount.put("y", amountInBigDecimal);
				paymentList.add(listOfUserEachEmployeeCount);
				
				//Invoice Outstanding (Outstanding)
				listOfUserEachEmployeeCount = new HashMap<String, Object>();
				outStandingAmount = outStandingAmount.subtract(amountInBigDecimal);
				listOfUserEachEmployeeCount.put("label", territoryName);
				listOfUserEachEmployeeCount.put("y", outStandingAmount);
				outStandingList.add(listOfUserEachEmployeeCount);
				
			}
			
			// Ajax response
            try 
            {
            	Map<String, Object> territoryWiseMonthlyPayableResult = new HashMap<String, Object>();
            	
            	territoryWiseMonthlyPayableResult.put("responseStatus", "Success");
            	territoryWiseMonthlyPayableResult.put("chartTitle", "Territory Wise Monthly Pay Status for "+monthsList[monthInt]+", "+yearInt);
            	territoryWiseMonthlyPayableResult.put("invoiceList", invoiceList);
            	territoryWiseMonthlyPayableResult.put("paymentList", paymentList);
            	territoryWiseMonthlyPayableResult.put("outStandingList", outStandingList);
            	
            	getMapToJsonObject(territoryWiseMonthlyPayableResult, response);
            }
            catch (EventHandlerException e)
            {
            	e.printStackTrace();
            	return "error";
            }
			
			return "success";
		}
		catch(GenericEntityException gee)
		{
			gee.printStackTrace();
			return "error";
		}
		finally
		{
			try {
				if(UtilValidate.isNotEmpty(userLoginsEli)) {
					userLoginsEli.close();
				}
				if(UtilValidate.isNotEmpty(territoryList)) {
					territoryList.close();
				}
			} catch (GenericEntityException e) {
				e.printStackTrace();
			}
		}
	}
}
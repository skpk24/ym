package org.ofbiz.backend.subscription;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.ofbiz.base.util.Debug;
import org.ofbiz.base.util.UtilHttp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.math.NumberUtils;
import org.ofbiz.entity.model.DynamicViewEntity;
import org.ofbiz.entity.model.ModelKeyMap;
import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilProperties;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.condition.EntityCondition;
import org.ofbiz.entity.condition.EntityOperator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.entity.util.EntityFindOptions;
import org.ofbiz.entity.util.EntityListIterator;
import org.ofbiz.entity.util.EntityQuery;
import org.ofbiz.service.DispatchContext;
import org.ofbiz.service.GenericServiceException;
import org.ofbiz.service.LocalDispatcher;
import org.ofbiz.service.ServiceUtil;
import org.ofbiz.webapp.event.EventHandlerException;

public class SubscriptionPackage
{
	public static final String module = SubscriptionPackage.class.getName();
	
	public static Map<String, Object> getListOfValues(DispatchContext dctx, Map<String, ? extends Object> context) throws GenericEntityException
	{
		Delegator delegator = dctx.getDelegator();
		
		int viewSizePerPage1 = (Integer) context.get("viewSizePerPage");
		int viewPageNub1 = (Integer) context.get("viewPageNub");
		
		String entityName = (String) context.get("entityName");
		String orderBy = (String) context.get("orderBy");
		String statusString= (String) context.get("statusString");
		String typeString= (String) context.get("typeString");
	
		List<EntityCondition> allConditions = new LinkedList<EntityCondition>();
		List<String> chkStatus = new ArrayList<String>();
		List<String> chkboxType = new ArrayList<String>();
		
		String[] chkValues=null, chkType=null;	
		
		if(entityName.equals("OrderHeader")){
			for(int i=2;i<11;i++){
				String status= (String) context.get("chkStatus"+i);
				if(UtilValidate.isNotEmpty(status)){
				  chkStatus.add(status);
				} 
			}
			
			for(int i=1;i<3;i++){
				String type= (String)context.get("chkboxType"+i);
				if(UtilValidate.isNotEmpty(type)){
					chkboxType.add(type);
				}
			}
			
			if(statusString!=null && statusString.compareTo("NULL")!=0){ 
				chkValues= statusString.trim().split("\\|");
				for(int i=0;i<chkValues.length;i++){
					chkStatus.add(chkValues[i]);
				}
			}
			if(typeString!=null && typeString.compareTo("NULL")!=0){
				chkType= typeString.trim().split("\\|");
				for(int i=0;i<chkType.length;i++){
					chkboxType.add(chkType[i]);
				}
			}
		
		    List<EntityCondition> statusConditions = new LinkedList<EntityCondition>();
		    if(chkStatus!=null){ 	
		        Iterator<String> itrStatus= chkStatus.iterator();
		        while(itrStatus.hasNext()){
		        	statusConditions.add(EntityCondition.makeCondition("statusId", EntityOperator.EQUALS, itrStatus.next()));
		        }
		    }   
		    
		    List<EntityCondition> typeConditions = new LinkedList<EntityCondition>();
		    if(chkboxType!=null){ 
		        Iterator<String> itrType= chkboxType.iterator();
		        while(itrType.hasNext()){
		            typeConditions.add(EntityCondition.makeCondition("orderTypeId", EntityOperator.EQUALS, itrType.next()));
		        }
		    }	
		    EntityCondition statusConditionsList = EntityCondition.makeCondition(statusConditions,  EntityOperator.OR);
		    EntityCondition typeConditionsList = EntityCondition.makeCondition(typeConditions, EntityOperator.OR);
		    if (statusConditions.size() > 0) {
		        allConditions.add(statusConditionsList);
		    }
		    if (typeConditions.size() > 0) {
		        allConditions.add(typeConditionsList);
		    }
		  
		}
		int viewSize1 = (!UtilValidate.isEmpty(viewSizePerPage1)) ? viewSizePerPage1 : 10;
		int viewPageNub2 = (!UtilValidate.isEmpty(viewPageNub1)) ? viewPageNub1 : 0;
		orderBy = (UtilValidate.isEmpty(orderBy)) ? "createdStamp" : orderBy;

		EntityFindOptions findOptions = new EntityFindOptions(true, EntityFindOptions.TYPE_SCROLL_INSENSITIVE, EntityFindOptions.CONCUR_READ_ONLY, true);
        findOptions.setMaxRows(viewSize1 * (viewPageNub2 + 1));
		
                    
		EntityListIterator listIt = EntityQuery.use(delegator)
                .from(entityName)
                .where(allConditions)
                .cursorScrollInsensitive()
                .maxRows(viewSize1 * (viewPageNub2 + 1))
                .orderBy(orderBy)
                .queryIterator();

		// get subset corresponding to pagination state
        List<GenericValue> subscriptionList = listIt.getPartialList(viewSize1 * viewPageNub2, viewSize1);
		int subscriptionListSize = listIt.getResultsSizeAfterPartialList();
		listIt.close();
        
        Debug.logInfo("size of subscriptionList: " + subscriptionListSize, module);
        //System.out.println("subscriptionList = "+subscriptionList);
		
        Map<String, Object> result =  ServiceUtil.returnSuccess();
		if(subscriptionList != null && subscriptionList.size() > 0 && subscriptionListSize > 0){
			result.put("subscriptionList", subscriptionList);
			int totalPageNub = ((subscriptionListSize % viewSize1) != 0) ? (subscriptionListSize/viewSize1) : (subscriptionListSize/viewSize1)-1;
			result.put("totalPageNub", totalPageNub);
		}
		
		if(chkStatus!=null && chkStatus.size()>0 ){
			result.put("chkStatus", chkStatus);
		}
		
		if(chkboxType!=null && chkboxType.size()>0){
			result.put("chkboxType", chkboxType);
		}
		
		return result;
	}
	
	public static String createSubscriptionProduct(HttpServletRequest request, HttpServletResponse response)
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
		
		String productId = request.getParameter("productId");
		String internalName = request.getParameter("internalName");
		String productPrice = request.getParameter("productPrice");
		String maxLifeTime = request.getParameter("maxLifeTime");
		String maxLifeTimeUomId = request.getParameter("maxLifeTimeUomId");
		String availableTime = request.getParameter("availableTime");
		String availableTimeUomId = request.getParameter("availableTimeUomId");
		String useCountLimit = request.getParameter("useCountLimit");
		String useTime = request.getParameter("useTime");
		String useTimeUomId = request.getParameter("useTimeUomId");
		String useRoleTypeId = request.getParameter("useRoleTypeId");
		String automaticExtend = request.getParameter("automaticExtend");
		String canclAutmExtTime = request.getParameter("canclAutmExtTime");
		String canclAutmExtTimeUomId = request.getParameter("canclAutmExtTimeUomId");
		String gracePeriodOnExpiry = request.getParameter("gracePeriodOnExpiry");
		String gracePeriodOnExpiryUomId = request.getParameter("gracePeriodOnExpiryUomId");
		
		Map<String, Object> contextMap = null;
		GenericValue chkProduct = null, subscriptionResource = null;
		
		Date presentTime = new Date();
        Timestamp presentDateTimestamp = new Timestamp(presentTime.getTime());
		
		if(UtilValidate.isNotEmpty(productId))
		{
			try
			{
				chkProduct = delegator.findOne("Product", UtilMisc.toMap("productId", productId), false);
				if(UtilValidate.isEmpty(chkProduct)) {
					//Check existence of Subscription Resource
					subscriptionResource = delegator.findOne("SubscriptionResource", UtilMisc.toMap("subscriptionResourceId", productId+"-SR"), false);
					if(UtilValidate.isNotEmpty(subscriptionResource)) {
						request.setAttribute("errorMsg", "Subscription Resource is already exist in this product id '"+productId+"' choose differenct one");
						return "error";
					}
				}
				else {
					request.setAttribute("errorMsg", "Product already exists");
					return "error";
				}
			}
			catch(GenericEntityException gee)
			{
				request.setAttribute("errorMsg", "Check Product ID");
				gee.printStackTrace();
				return "error";
			}
			
			if(UtilValidate.isEmpty(chkProduct))
			{
				try
				{
					HttpSession session = request.getSession(true);
					GenericValue userLogin = (GenericValue) session.getAttribute("userLogin");
					
					//Creating product
					contextMap = new HashMap<String, Object>();
					contextMap.put("productId", productId);
					contextMap.put("internalName", internalName);
					contextMap.put("productName", internalName);
					contextMap.put("productTypeId", "DIGITAL_GOOD");
					contextMap.put("isVirtual", "N");
					contextMap.put("isVariant", "N");
					contextMap.put("userLogin", userLogin);
					
					Map<String, Object> productCreateResult = dispatcher.runSync("createProduct", contextMap);
					
					//Creating price
					if(UtilValidate.isNotEmpty(productCreateResult) && productCreateResult.get("responseMessage").equals("success"))
					{
						//Associating Category to Product
						dispatcher.runSync("safeAddProductToCategory", UtilMisc.toMap("productId", productId, "productCategoryId", "SLV_PROMOTIONS", "fromDate", presentDateTimestamp, "userLogin", userLogin));
						
						//Updating product table by adding primaryProductCategoryId
						dispatcher.runSync("updateProduct", UtilMisc.toMap("productId", productId, "primaryProductCategoryId", "SLV_PROMOTIONS", "userLogin", userLogin));
						
						if(UtilValidate.isNotEmpty(productPrice))
						{
							String currencyDefault = UtilProperties.getPropertyValue("general", "currency.uom.id.default");
							if(UtilValidate.isEmpty(currencyDefault)) { currencyDefault =  "INR"; }
							
							contextMap = new HashMap<String, Object>();
							contextMap.put("productId", productId);
							contextMap.put("productPriceTypeId", "DEFAULT_PRICE");
							contextMap.put("productPricePurposeId", "PURCHASE");
							contextMap.put("currencyUomId", currencyDefault);
							contextMap.put("productStoreGroupId", "_NA_");
							contextMap.put("price", new BigDecimal(productPrice));
							contextMap.put("taxInPrice", "Y");
							contextMap.put("userLogin", userLogin);
							
							dispatcher.runSync("createProductPrice", contextMap);
						}
						
						try
						{
							//Creating new Subscription Resource
							subscriptionResource = delegator.makeValue("SubscriptionResource", UtilMisc.toMap("subscriptionResourceId", productId+"-SR", "description", productId+"-SR", "webSiteId", "WebStore"));
							subscriptionResource.create();
						}
						catch(GenericEntityException gee)
						{
							request.setAttribute("errorMsg", "Check SubscriptionResource ID");
							gee.printStackTrace();
							return "error";
						}
						
						//Adding Subscription Resource to the Product
						contextMap = new HashMap<String, Object>();
						contextMap.put("productId", productId);
						contextMap.put("subscriptionResourceId", productId+"-SR");
						contextMap.put("fromDate", presentDateTimestamp);
						contextMap.put("maxLifeTime", (UtilValidate.isNotEmpty(maxLifeTime) && NumberUtils.isNumber(maxLifeTime)) ? new BigDecimal(maxLifeTime) : null);
						contextMap.put("maxLifeTimeUomId", maxLifeTimeUomId);
						contextMap.put("availableTime", (UtilValidate.isNotEmpty(availableTime) && NumberUtils.isNumber(availableTime)) ? new BigDecimal(availableTime) : null);
						contextMap.put("availableTimeUomId", availableTimeUomId);
						contextMap.put("useCountLimit", (UtilValidate.isNotEmpty(useCountLimit) && NumberUtils.isNumber(useCountLimit)) ? new BigDecimal(useCountLimit) : null);
						contextMap.put("useTime", (UtilValidate.isNotEmpty(useTime) && NumberUtils.isNumber(useTime)) ? new BigDecimal(useTime) : null);
						contextMap.put("useTimeUomId", useTimeUomId);
						contextMap.put("useRoleTypeId", useRoleTypeId);
						contextMap.put("automaticExtend", automaticExtend);
						contextMap.put("canclAutmExtTime", (UtilValidate.isNotEmpty(canclAutmExtTime) && NumberUtils.isNumber(canclAutmExtTime)) ? new BigDecimal(canclAutmExtTime) : null);
						contextMap.put("canclAutmExtTimeUomId", canclAutmExtTimeUomId);
						contextMap.put("gracePeriodOnExpiry", (UtilValidate.isNotEmpty(gracePeriodOnExpiry) && NumberUtils.isNumber(gracePeriodOnExpiry)) ? new BigDecimal(gracePeriodOnExpiry) : null);
						contextMap.put("gracePeriodOnExpiryUomId", gracePeriodOnExpiryUomId);
						contextMap.put("userLogin", userLogin);
						
						dispatcher.runSync("createProductSubscriptionResource", contextMap);
					}
				}
				catch(GenericServiceException gse)
				{
					request.setAttribute("errorMsg", "Service Error");
					gse.printStackTrace();
					return "error";
				}
			}
		}
		
		return "success";
	}
	
	public static Map<String, Object> listOfSubscriptionResource(DispatchContext dctx, Map<String, ? extends Object> context){
		Delegator delegator = dctx.getDelegator();
		
		DynamicViewEntity dynamicViewEntity = new DynamicViewEntity();
		dynamicViewEntity.addMemberEntity("PROD", "Product");
		dynamicViewEntity.addMemberEntity("PRICE", "ProductPrice");
		dynamicViewEntity.addMemberEntity("SUBRES", "ProductSubscriptionResource");
		dynamicViewEntity.addViewLink("PROD", "PRICE", false, ModelKeyMap.makeKeyMapList("productId"));
		dynamicViewEntity.addViewLink("PROD", "SUBRES", false, ModelKeyMap.makeKeyMapList("productId"));
		dynamicViewEntity.addAlias("PROD", "internalName");
		dynamicViewEntity.addAlias("PRICE", "price");
		dynamicViewEntity.addAlias("SUBRES", "productId");
		dynamicViewEntity.addAlias("SUBRES", "maxLifeTime");
		dynamicViewEntity.addAlias("SUBRES", "maxLifeTimeUomId");
		dynamicViewEntity.addAlias("SUBRES", "availableTime");
		dynamicViewEntity.addAlias("SUBRES", "availableTimeUomId");
		dynamicViewEntity.addAlias("SUBRES", "useCountLimit");
		dynamicViewEntity.addAlias("SUBRES", "useTime");
		dynamicViewEntity.addAlias("SUBRES", "useTimeUomId");
		dynamicViewEntity.addAlias("SUBRES", "useRoleTypeId");
		dynamicViewEntity.addAlias("SUBRES", "automaticExtend");
		dynamicViewEntity.addAlias("SUBRES", "canclAutmExtTime");
		dynamicViewEntity.addAlias("SUBRES", "canclAutmExtTimeUomId");
		dynamicViewEntity.addAlias("SUBRES", "gracePeriodOnExpiry");
		dynamicViewEntity.addAlias("SUBRES", "gracePeriodOnExpiryUomId");
		
		int viewSizePerPage = (Integer) context.get("viewSizePerPage");
		int viewPageNubStr = (Integer) context.get("viewPageNub");
		
        Map<String, Object> result = ServiceUtil.returnSuccess();
        
        try{
        	int viewSize = (!UtilValidate.isEmpty(viewSizePerPage)) ? viewSizePerPage : 10;
        	int viewPageNub = (!UtilValidate.isEmpty(viewPageNubStr)) ? viewPageNubStr : 0;
        	
        	EntityFindOptions findOptions = new EntityFindOptions(true, EntityFindOptions.TYPE_SCROLL_INSENSITIVE, EntityFindOptions.CONCUR_READ_ONLY, true);
        	findOptions.setMaxRows(viewSize * (viewPageNub + 1));

        	EntityListIterator subResourceList = delegator.findListIteratorByCondition(dynamicViewEntity, null, null, null, null, findOptions);
        	
        	// get subset corresponding to pagination state
            List<GenericValue> subscriptionResourceList = subResourceList.getPartialList(viewSize * viewPageNub, viewSize);
    		
            int subscriptionResListSize = subResourceList.getResultsSizeAfterPartialList();

    		if(subscriptionResourceList != null && subscriptionResourceList.size() > 0 && subscriptionResListSize > 0){
    			int totalPageNub = ((subscriptionResListSize % viewSize) != 0) ? (subscriptionResListSize/viewSize) : (subscriptionResListSize/viewSize)-1;
    			result.put("subscriptionResourceList", subscriptionResourceList);
    			result.put("viewSizePerPage", viewSize);
    			result.put("totalPageNum", totalPageNub);
    		}
        	
    		subResourceList.close();
        	
        }catch(GenericEntityException gee){
        	gee.printStackTrace();
        }
		
		return result;
	}
	
	public static String viewSubscriptionResource(HttpServletRequest request, HttpServletResponse response){
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		DynamicViewEntity productPriceSubRes = new DynamicViewEntity();
		productPriceSubRes.addMemberEntity("PROD", "Product");
		productPriceSubRes.addMemberEntity("PRICE", "ProductPrice");
		productPriceSubRes.addMemberEntity("SUBRES", "ProductSubscriptionResource");
		productPriceSubRes.addViewLink("PROD", "PRICE", false, ModelKeyMap.makeKeyMapList("productId"));
		productPriceSubRes.addViewLink("PROD", "SUBRES", false, ModelKeyMap.makeKeyMapList("productId"));
		productPriceSubRes.addAlias("PROD", "internalName");
		productPriceSubRes.addAlias("PRICE", "price");
		productPriceSubRes.addAlias("SUBRES", "productId");
		productPriceSubRes.addAlias("SUBRES", "maxLifeTime");
		productPriceSubRes.addAlias("SUBRES", "maxLifeTimeUomId");
		productPriceSubRes.addAlias("SUBRES", "availableTime");
		productPriceSubRes.addAlias("SUBRES", "availableTimeUomId");
		productPriceSubRes.addAlias("SUBRES", "useCountLimit");
		productPriceSubRes.addAlias("SUBRES", "useTime");
		productPriceSubRes.addAlias("SUBRES", "useTimeUomId");
		productPriceSubRes.addAlias("SUBRES", "useRoleTypeId");
		productPriceSubRes.addAlias("SUBRES", "automaticExtend");
		productPriceSubRes.addAlias("SUBRES", "canclAutmExtTime");
		productPriceSubRes.addAlias("SUBRES", "canclAutmExtTimeUomId");
		productPriceSubRes.addAlias("SUBRES", "gracePeriodOnExpiry");
		productPriceSubRes.addAlias("SUBRES", "gracePeriodOnExpiryUomId");
		
		String subResourceProductId = request.getParameter("productId");
		
		try{
			EntityListIterator workshopListIterator = delegator.findListIteratorByCondition(productPriceSubRes, EntityCondition.makeCondition("productId", EntityOperator.EQUALS, subResourceProductId), null, null, null, null);

        	GenericValue nextValue = null;
        	while((nextValue = (GenericValue) workshopListIterator.next()) != null) {
        		request.setAttribute("workshopListIterator", nextValue);
			}
        	
        	workshopListIterator.close();
        	
		}catch(GenericEntityException gee){
			gee.printStackTrace();
			return "error";
		}
		
		return "success";
	}
	

	public static String writeOffPayment(HttpServletRequest request, HttpServletResponse response)throws IOException
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		
		String paymentId = request.getParameter("paymentId");
		String writeOff = request.getParameter("writeOffStatus");

		if(paymentId != null && paymentId != "" && writeOff != "" && writeOff != null){
			try{
				Map<String, Object> attrMap = UtilHttp.getJSONAttributeMap(request);
				
				GenericValue gv = delegator.makeValue("Payment", UtilMisc.toMap("paymentId",paymentId,"statusId", "INVOICE_WRITEOFF"));
				gv.store();
				
				attrMap.put("paymentId", paymentId);
				attrMap.put("successMessage", "Write Off");
				
				// Ajax response
				try 
				{
					DashboardContent.getMapToJsonObject(attrMap, response);
				}
				catch (EventHandlerException e)
				{
					e.printStackTrace();
					return "error";
				}
				return "success";
			}catch(GenericEntityException e){
				e.printStackTrace();
				return "error";
			}
		}else{
			return "error";
		}
	}
	
	public static String updateSubscriptionResource(HttpServletRequest request, HttpServletResponse response){
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
		
		String productId = request.getParameter("productId");
		String internalName = request.getParameter("internalName");
		String productPrice = request.getParameter("productPrice");
		String maxLifeTime = request.getParameter("maxLifeTime");
		String maxLifeTimeUomId = request.getParameter("maxLifeTimeUomId");
		String availableTime = request.getParameter("availableTime");
		String availableTimeUomId = request.getParameter("availableTimeUomId");
		String useCountLimit = request.getParameter("useCountLimit");
		String useTime = request.getParameter("useTime");
		String useTimeUomId = request.getParameter("useTimeUomId");
		String useRoleTypeId = request.getParameter("useRoleTypeId");
		String automaticExtend = request.getParameter("automaticExtend");
		String canclAutmExtTime = request.getParameter("canclAutmExtTime");
		String canclAutmExtTimeUomId = request.getParameter("canclAutmExtTimeUomId");
		String gracePeriodOnExpiry = request.getParameter("gracePeriodOnExpiry");
		String gracePeriodOnExpiryUomId = request.getParameter("gracePeriodOnExpiryUomId");
		
		Map<String, Object> contextMap = null;
		
		GenericValue checkSubId = null ;
		
		if(UtilValidate.isNotEmpty(productId)){
		
			try{
				GenericValue chckPrdt = delegator.findOne("Product", UtilMisc.toMap("productId", productId), false);
				
				if(UtilValidate.isEmpty(chckPrdt)){
					request.setAttribute("errorMsg", "Product with Id "+productId+" does not exist to update");
					return "error";
					
				}else if(UtilValidate.isNotEmpty(chckPrdt)){
					checkSubId = delegator.findOne("SubscriptionResource", UtilMisc.toMap("subscriptionResourceId", productId+"-SR"), false);
					
					if(UtilValidate.isEmpty(checkSubId)){
						request.setAttribute("errorMsg", "Product with Id "+productId+" does not exist to update");
						return "error";
					}
				}
				
			}catch(GenericEntityException gee){
				request.setAttribute("errorMsg", "Check Product Id");
				gee.printStackTrace();
			}
			
			if(UtilValidate.isNotEmpty(checkSubId)){
				
				try{
					HttpSession session = request.getSession(true);
					GenericValue userLogin = (GenericValue) session.getAttribute("userLogin");
					
					//Creating product
					contextMap = new HashMap<String, Object>();
					contextMap.put("productId", productId);
					contextMap.put("internalName", internalName);
					contextMap.put("productName", internalName);
					contextMap.put("userLogin", userLogin);
					
					dispatcher.runSync("updateProduct", contextMap);
					
					if(UtilValidate.isNotEmpty(productPrice))
					{
						String currencyDefault = UtilProperties.getPropertyValue("general", "currency.uom.id.default");
						if(UtilValidate.isEmpty(currencyDefault)) { currencyDefault =  "INR"; }
						
						contextMap = new HashMap<String, Object>();
						contextMap.put("productId", productId);
						contextMap.put("productPriceTypeId", "DEFAULT_PRICE");
						contextMap.put("productPricePurposeId", "PURCHASE");
						contextMap.put("currencyUomId", currencyDefault);
						contextMap.put("productStoreGroupId", "_NA_");
						contextMap.put("price", new BigDecimal(productPrice));
						contextMap.put("userLogin", userLogin);
						
						List<GenericValue> priceDtls = null;
						Timestamp fromDate = null;
						
						try{
							priceDtls = delegator.findList("ProductPrice", EntityCondition.makeCondition("productId", EntityOperator.EQUALS, productId), UtilMisc.toSet("fromDate"), null, null, false);
							
							
							Iterator<GenericValue> itr = priceDtls.iterator();
							while(itr.hasNext()){
								GenericValue object = itr.next();
								fromDate = object.getTimestamp("fromDate");
							}
							
						}catch(GenericEntityException gee){
							gee.printStackTrace();
							return "error";
						}
						
						if(UtilValidate.isNotEmpty(fromDate)){
							contextMap.put("fromDate", fromDate);
							
							dispatcher.runSync("updateProductPrice", contextMap);
						}
					}
					
					//Adding Subscription Resource to the Product
					contextMap = new HashMap<String, Object>();
					contextMap.put("productId", productId);
					contextMap.put("subscriptionResourceId", productId+"-SR");
					contextMap.put("maxLifeTime", (UtilValidate.isNotEmpty(maxLifeTime) && NumberUtils.isNumber(maxLifeTime)) ? new BigDecimal(maxLifeTime) : null);
					contextMap.put("maxLifeTimeUomId", maxLifeTimeUomId);
					contextMap.put("availableTime", (UtilValidate.isNotEmpty(availableTime) && NumberUtils.isNumber(availableTime)) ? new BigDecimal(availableTime) : null);
					contextMap.put("availableTimeUomId", availableTimeUomId);
					contextMap.put("useCountLimit", (UtilValidate.isNotEmpty(useCountLimit) && NumberUtils.isNumber(useCountLimit)) ? new BigDecimal(useCountLimit) : null);
					contextMap.put("useTime", (UtilValidate.isNotEmpty(useTime) && NumberUtils.isNumber(useTime)) ? new BigDecimal(useTime) : null);
					contextMap.put("useTimeUomId", useTimeUomId);
					contextMap.put("useRoleTypeId", useRoleTypeId);
					contextMap.put("automaticExtend", automaticExtend);
					contextMap.put("canclAutmExtTime", (UtilValidate.isNotEmpty(canclAutmExtTime) && NumberUtils.isNumber(canclAutmExtTime)) ? new BigDecimal(canclAutmExtTime) : null);
					contextMap.put("canclAutmExtTimeUomId", canclAutmExtTimeUomId);
					contextMap.put("gracePeriodOnExpiry", (UtilValidate.isNotEmpty(gracePeriodOnExpiry) && NumberUtils.isNumber(gracePeriodOnExpiry)) ? new BigDecimal(gracePeriodOnExpiry) : null);
					contextMap.put("gracePeriodOnExpiryUomId", gracePeriodOnExpiryUomId);
					contextMap.put("userLogin", userLogin);

					List<GenericValue> updtPrdtSubRes = null;
					Timestamp psrFromDate = null;
					
					try{
						updtPrdtSubRes = delegator.findList("ProductSubscriptionResource", EntityCondition.makeCondition("productId", EntityOperator.EQUALS, productId), UtilMisc.toSet("fromDate"), null, null, false);
						
						Iterator<GenericValue> pdrItr = updtPrdtSubRes.iterator();
						while(pdrItr.hasNext()){
							GenericValue obj = pdrItr.next();
							psrFromDate = obj.getTimestamp("fromDate");
						}
						
					}catch(GenericEntityException gee){
						gee.printStackTrace();
						return "error";
					}
					
					if(UtilValidate.isNotEmpty(psrFromDate)){
						contextMap.put("fromDate", psrFromDate);
						dispatcher.runSync("updateProductSubscriptionResource", contextMap);
					}

					}catch(GenericServiceException gse){
						request.setAttribute("errorMsg", "Service Error");
						gse.printStackTrace();
						return "error";
				}
			}
			
			return "success";
				
		}else{
			request.setAttribute("errorMsg", "Product Id is Required");
			return "error";
		}
	}
}
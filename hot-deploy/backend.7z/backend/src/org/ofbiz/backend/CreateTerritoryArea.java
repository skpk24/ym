package org.ofbiz.backend;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Map;
import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ofbiz.base.util.UtilMisc;
import org.ofbiz.base.util.UtilValidate;
import org.ofbiz.entity.Delegator;
import org.ofbiz.entity.GenericEntityException;
import org.ofbiz.entity.GenericValue;
import org.ofbiz.entity.condition.EntityCondition;
import org.ofbiz.entity.condition.EntityOperator;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import org.ofbiz.base.lang.JSON;

public class CreateTerritoryArea
{
	public static String createTerritory(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException, IOException
	{
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		String geoName = request.getParameter("geoName");
		String geoCode = request.getParameter("geoCode");
		String abbreviation = request.getParameter("abbreviation");
		String geoId = delegator.getNextSeqId("Geo");
		
		if(UtilValidate.isNotEmpty(geoName) && UtilValidate.isNotEmpty(geoCode) && UtilValidate.isNotEmpty(abbreviation)){
			geoName = geoName+" ("+geoCode+")";
			
			try{
				GenericValue insertData = delegator.makeValue("Geo", UtilMisc.toMap("geoId", geoId, "geoTypeId", "TERRITORY", "geoName", geoName, "geoCode", geoCode, "abbreviation", abbreviation));
				insertData.create();
			}catch(GenericEntityException e){
				e.printStackTrace();
				return "error";
			}
			
			return "success";
		
		}else{
			request.setAttribute("msg", "Please enter the Form details");
			return "error";
		}

	}
	
	public static String createArea(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException
	{		
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		String territoryId = request.getParameter("territory1");
		String geoName = request.getParameter("geoName1");
		String geoCode = request.getParameter("geoCode1");
		String abbreviation = request.getParameter("abbreviation1");
		
		if(UtilValidate.isNotEmpty(geoName) && UtilValidate.isNotEmpty(geoCode) && UtilValidate.isNotEmpty(abbreviation)){
			String geoId = delegator.getNextSeqId("Geo");
			geoName = geoName+" (Area)";
			
			try{
				GenericValue insertData = delegator.makeValue("Geo", UtilMisc.toMap("geoId", geoId, "geoTypeId", "AREA", "geoName", geoName, "geoCode", geoCode, "abbreviation", abbreviation));
				insertData.create();
				
				GenericValue insertIntoGeoAssoc = delegator.makeValue("GeoAssoc", UtilMisc.toMap("geoId", territoryId, "geoIdTo", geoId, "geoAssocTypeId", "TERRITORY_AREA"));
				insertIntoGeoAssoc.create();
				
			}catch(GenericEntityException gee){
				gee.printStackTrace();
				return "error";
			}
			
			return "success";
		}
		else{
			request.setAttribute("errormsg", "Please enter the Form details");
			return "error";
		}
		
	}
	
	public static String getTerritory(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException,  UnsupportedEncodingException, IOException
	{	
		Delegator delegator = (Delegator) request.getAttribute("delegator");
		Map<String, String> geoNameMap = new LinkedHashMap<String, String>();
		
		try{
			List<GenericValue> territoryList = delegator.findList("Geo", EntityCondition.makeCondition("geoTypeId", EntityOperator.EQUALS, "TERRITORY"), null, UtilMisc.toList("geoName"), null, false);
			
			Iterator<GenericValue> itr = territoryList.listIterator();
			while(itr.hasNext())
			{
				GenericValue geoName = itr.next();
				geoNameMap.put(geoName.getString("geoId"), geoName.getString("geoName"));
			}
			
		}catch(GenericEntityException gee){
			gee.printStackTrace();
			return "error";
		}

		if(UtilValidate.isNotEmpty(geoNameMap)){
			JSON json = JSON.from(geoNameMap);
			String jsonStr = json.toString();
			response.setContentType("application/json");
			response.setContentLength(jsonStr.getBytes("UTF8").length);
			Writer out;
			
			try {
				out = response.getWriter();
				out.write(jsonStr);
			    out.flush();
			}catch (IOException e) {
				e.printStackTrace();
				return "error";
			}
		}
		
		return "success";
	}
	
}

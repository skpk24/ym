
println("Hello Test Groovy *****************");

Enumeration mySession = session.getAttributeNames();
while (mySession.hasMoreElements()) {
	String mySessionVarName = (String)mySession.nextElement();
	String myValue = (String)session.getValue(mySessionVarName);
	println(mySessionVarName + "=" + myValue + "<br>");
}